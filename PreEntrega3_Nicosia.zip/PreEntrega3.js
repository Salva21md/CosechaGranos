/// Pre entrega # 3

//Maiz
// Variable para almacenar el historial de rendimientos
var rendimientosPasadosMaiz = [
  {campaña :12/13,Yield:6.7},
  {campaña :13/14,Yield:7.8},
  {campaña :14/15,Yield:8.9},
  {campaña :15/16,Yield:7.3},
  {campaña :16/17,Yield:11.7},
  {campaña :17/18,Yield:9.4},
  {campaña :18/19,Yield:7.8},
  {campaña :19/20,Yield:10.3},
  {campaña :20/21,Yield:8.96},
  {campaña :21/22,Yield:12.43}
];

//Soja
// Variable para almacenar el historial de rendimientos
var rendimientosPasadosSoja = [
  {campaña :12/13,Yield:2.7},
  {campaña :13/14,Yield:3.8},
  {campaña :14/15,Yield:4.9},
  {campaña :15/16,Yield:3.3},
  {campaña :16/17,Yield:4.5},
  {campaña :17/18,Yield:3.4},
  {campaña :18/19,Yield:2.8},
  {campaña :19/20,Yield:4.2},
  {campaña :20/21,Yield:3.45},
  {campaña :21/22,Yield:4.43}
];

// Variable para almacenar los promedios de rendimiento
//var promediosRendimiento = {
  //"maíz": 8.992,
  //"soja": 3.620
//};


function calcularPromedioRendimiento(rendimientos, cultivo) {
  var suma = 0;
  for (var i = 0; i < rendimientos.length; i++) {
    suma += rendimientos[i].Yield;
  }
  return suma / rendimientos.length;
}

var promediosRendimiento = {};


// Cálculo del promedio de rendimiento para maíz
promediosRendimiento["maíz"] = calcularPromedioRendimiento(rendimientosPasadosMaiz, "maíz");

// Cálculo del promedio de rendimiento para soja
promediosRendimiento["soja"] = calcularPromedioRendimiento(rendimientosPasadosSoja, "soja");





function calcularRendimientoYCamiones() {
  // Obtener los valores del formulario
  var cultivo = document.getElementById("cultivo").value.toLowerCase();
  var numMazorcas = parseInt(document.getElementById("numMazorcas").value);
  var numGranosMaiz = parseInt(document.getElementById("numGranos").value);
var numGranosSoja = parseInt(document.getElementById("numGranosSoja").value);
  var numPlantas = parseInt(document.getElementById("numPlantas").value);
  var pesoGranos = parseFloat(document.getElementById("pesoGranos").value);
  var numHectareas = parseInt(document.getElementById("numHectareas").value);

  // Verificar si el cultivo es válido
  if (cultivo !== "maíz" && cultivo !== "soja") {
    alert("Cultivo no válido");
    return;
  }

  // Calcular el rendimiento según el cultivo
  var rendimiento;
  if (cultivo === "maíz") {
  var granosHa = numMazorcas * numGranosMaiz;
  rendimiento = ((granosHa * 300) / 1000) / 1000000;
} else if (cultivo === "soja") {
  var granosPorMetro = numPlantas * numGranosSoja;
  rendimiento = (granosPorMetro * pesoGranos) / 1000000;
}

  // Calcular el peso total de la cosecha y el número de camiones necesarios
  var pesoTotal = numHectareas * rendimiento;
  var numCamiones = Math.ceil(pesoTotal / 32);

  
 // Mostrar el resultado al usuario
 Swal.fire({
    icon: 'success',
    title: 'Resultados',
    html:
      '<p>El rendimiento promedio es de ' + rendimiento.toFixed(2) + ' toneladas/Ha Para cosechar.</p>' +
      '<p>El peso total de granos a cosecha es de ' + pesoTotal.toFixed(2) + ' Toneladas en ' + numHectareas + ' hectáreas de ' + cultivo + '.</p>' +
      '<p>Con este rendimiento, se estima que, se necesitan ' + numCamiones + ' camiones.</p>'
  });

  // Graficar los rendimientos pasados y actuales
  var rendimientosPasados = [];
  if (cultivo === "maíz") {
    rendimientosPasados = rendimientosPasadosMaiz;
  } else if (cultivo === "soja") {
    rendimientosPasados = rendimientosPasadosSoja;
  }

  graficarRendimientos(rendimientosPasados, rendimiento, cultivo);
}

function graficarRendimientos(rendimientos, rendimientoActual, cultivo) {
  // Obtener el elemento canvas del DOM
  var canvas = document.getElementById("grafico-rendimientos");
  
  // Agregar el promedio de rendimiento al array de rendimientos pasados
  rendimientos = rendimientos.concat({campaña: "Promedio", Yield: promediosRendimiento[cultivo]});
  
  // Crear el gráfico utilizando la librería Chart.js
  var ctx = canvas.getContext("2d");
  var chart = new Chart(ctx, {
  type: "bar",
  data: {
  labels: ["Promedio de rendimientos pasados", "Rendimiento actual"],
  datasets: [
  {label: "Rendimiento",
  data: [calcularPromedioRendimiento(rendimientos, cultivo), rendimientoActual],
  backgroundColor: ["blue", "green"],
  borderWidth: 0.5
  }]
  },
  options: {
    responsive: true,
    maintainAspectRatio: true,
    scales: {
      yAxes: [
        {
          ticks: {
            beginAtZero: true,
          },
        },
      ],
      xAxes: [
        {
          barThickness: 50, // Modificar el ancho de las barras
          maxBarThickness: 10, // Establecer un tamaño máximo para las barras
        },
      ],
    },
  },
});
  }

  

  function obtenerClima() {
  // Obtener la ubicación del usuario
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(function(position) {
      // Obtener las coordenadas de la ubicación del usuario
      var latitud = position.coords.latitude;
      var longitud = position.coords.longitude;

      // Llamar a la API de clima
      var urlClima = "https://api.openweathermap.org/data/2.5/weather?lat=" + latitud + "&lon=" + longitud + "&appid=2c6d095d5aca786763c287d8da8af554";
      var urlForecast = "https://api.openweathermap.org/data/2.5/forecast?lat=" + latitud + "&lon=" + longitud + "&appid=2c6d095d5aca786763c287d8da8af554";

      Promise.all([fetch(urlClima), fetch(urlForecast)])
        .then(([resClima, resForecast]) => Promise.all([resClima.json(), resForecast.json()]))
        .then(([dataClima, dataForecast]) => {
          // Mostrar los datos del clima actual en el nuevo div
          var climaDiv = document.getElementById("clima");
          var temperatura = (dataClima.main.temp - 273.15).toFixed(1); // Convertir la temperatura a grados Celsius
          var descripcion = dataClima.weather[0].description;
          climaDiv.innerHTML = "El clima actual es de " + temperatura + "°C y " + descripcion + ".";

          // Mostrar los datos del pronóstico del tiempo en el nuevo div
          var forecastDiv = document.getElementById("forecast");
          var table = "<table class='table'><thead><tr><th>Fecha</th><th>Temperatura (°C)</th><th>Descripción</th><th>Precipitación (mm)</th></tr></thead><tbody>";
            dataForecast.list.forEach(item => {
              var fecha = new Date(item.dt * 1000).toLocaleDateString();
              var temperatura = (item.main.temp - 273.15).toFixed(1);
              var descripcion = item.weather[0].description;
              var precipitacion = item.rain ? item.rain["3h"] : 0;
              table += "<tr><td>" + fecha + "</td><td>" + temperatura + "</td><td>" + descripcion + "</td><td>" + precipitacion + "</td></tr>";
            });
            table += "</tbody></table>";
            forecastDiv.innerHTML = table;

          // Agregar las temperaturas al dataset del chart
          var chart = new Chart(document.getElementById("grafico-temperaturas"), {
            type: 'line',
            data: {
              labels: [],
              datasets: [{
                label: 'Temperaturas',
                backgroundColor: 'rgba(54, 162, 235, 0.2)',
                borderColor: 'rgba(54, 162, 235, 1)',
                data: [],
                fill: false
              }]
            },
            options: {
              responsive: true,
              title: {
                display: true,
                text: 'Gráfico de temperaturas'
              },
              scales: {
                xAxes: [{
                  display: true,
                  scaleLabel: {
                    display: true,
                    labelString: 'Fechas'
                  }
                }],
                yAxes: [{
                  display: true,
                  scaleLabel: {
                    display: true,
                    labelString: 'Temperaturas (°C)'
                  }
                }]
              }
            }
          })


// Agregar los conjuntos de datos al objeto de gráfico
dataForecast.list.forEach(item => {
  var fecha = new Date(item.dt * 1000).toLocaleDateString();
  var temperatura = (item.main.temp - 273.15).toFixed(1);
  chart.data.labels.push(fecha); // Agregar la fecha al conjunto de etiquetas
  chart.data.datasets[0].data.push(temperatura);
})

// Crear el gráfico de precipitaciones utilizando la librería Chart.js
var ctx2 = document.getElementById("grafico-precipitaciones").getContext("2d");
var chart2 = new Chart(ctx2, {
  type: 'line',
  data: {
    labels: [],
    datasets: [{
      label: 'Lluvia (mm)',
      backgroundColor: 'rgba(255, 99, 132, 0.2)',
      borderColor: 'rgba(255, 99, 132, 1)',
      data: [],
      fill: false
    }]
  },
  options: {
    responsive: true,
    title: {
      display: true,
      text: 'Gráfico de lluvia'
    },
    scales: {
      xAxes: [{
        display: true,
        scaleLabel: {
          display: true,
          labelString: 'Fechas'
        }
      }],
      yAxes: [{
        display: true,
        scaleLabel: {
          display: true,
          labelString: 'Lluvia (mm)'
        }
      }]
    }
  }
});

// Agregar los datos de lluvia al dataset del chart
dataForecast.list.forEach(item => {
  var fecha = new Date(item.dt * 1000).toLocaleDateString();
  var lluvia = item.rain ? item.rain["3h"] : 0;
  chart2.data.labels.push(fecha); // Agregar la fecha al conjunto de etiquetas
  chart2.data.datasets[0].data.push(lluvia);
});

chart2.update();

  
  chart.update();
        })
        .catch(error => {
          console.error("Error al llamar a la API de clima:", error);
        });
    });
  } else {
    console.error("La geolocalización no está disponible en este navegador.");
  }

chart.update();


}

obtenerClima();

 

// Llamar a la función obtenerClima al hacer clic en el botón de actualizar clima
var btnActualizarClima = document.getElementById("btnActualizarClima");
btnActualizarClima.addEventListener("click", obtenerClima);

var btnActualizarForecast = document.getElementById("btnforecast");
btnActualizarForecast.addEventListener("click", obtenerClima);